<?php

$page = $_GET['page'] ?? 'index.html';

if (file_exists($page)) {
    include($page);
} else {
    echo "<h1>404 Not Found</h1><p>La página no existe.</p>";
}

?>