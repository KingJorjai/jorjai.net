const express = require('express');
const app = express();
const path = require('path');
const fs = require('fs');

const FLAG = "ikerlan{fake_flag}";

fs.writeFileSync('flag.txt', FLAG);

const is_safe = (input) => {
    const forbidden_words = ['flag', 'etc', 'passwd', '..', '/', '%'];
    for (const word of forbidden_words) {
        if (input.includes(word)) {
            console.log(`Petición bloqueada por la palabra clave: ${word}`);
            return false;
        }
    }
    return true;
};

app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'index.html'));
});

app.get('/style.css', (req, res) => {
    res.sendFile(path.join(__dirname, 'style.css'));
});

app.get('/search', (req, res) => {
    const search_query = req.query.q;

    if (!search_query || search_query.length === 0) {
        return res.status(400).send("No se proporcionó una consulta de búsqueda.");
    }

    if (!is_safe(search_query)) {
        return res.status(403).send("Consulta inválida. Has usado una palabra prohibida.");
    }
    
    const all_queries = req.query.q;
    
    if (Array.isArray(all_queries) && all_queries.length > 1) {
        const file_path = all_queries.join("");
        
        try {
            const content = fs.readFileSync(file_path, 'utf8');
            return res.status(200).send(`Contenido encontrado: <br><br> ${content}`);
        } catch (error) {
            console.log(error);
            return res.status(404).send("Archivo no encontrado.");
        }
    } else {
        return res.send(`Búsqueda: "${search_query}"`);
    }
});

app.listen(3000, () => {
    console.log('Servidor escuchando en http://localhost:3000');
});