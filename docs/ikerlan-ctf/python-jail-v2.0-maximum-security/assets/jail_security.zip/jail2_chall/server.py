import socket
import threading
import subprocess
import os
import time

class JailServer:
    def __init__(self, host='0.0.0.0', port=9999):
        self.host = host
        self.port = port
        self.socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.active_connections = 0
        self.max_connections = 10
        
    def handle_client(self, client_socket, address):
        print(f"[+] Nueva conexión desde {address[0]}:{address[1]}")
        
        try:
            client_socket.settimeout(300)
            
            process = subprocess.Popen(
                ['python3', '/app/jail.py'],
                stdin=subprocess.PIPE,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                preexec_fn=os.setsid
            )
            
            def send_output():
                try:
                    while True:
                        output = process.stdout.read(1)
                        if not output:
                            break
                        client_socket.send(output.encode())
                except:
                    pass
            
            output_thread = threading.Thread(target=send_output)
            output_thread.daemon = True
            output_thread.start()
            
            while True:
                try:
                    data = client_socket.recv(1024)
                    if not data:
                        break
                    
                    if len(data) > 500:
                        continue
                        
                    process.stdin.write(data.decode())
                    process.stdin.flush()
                    
                except:
                    break
                    
        except Exception as e:
            print(f"[-] Error con cliente {address[0]}:{address[1]}: {e}")
        finally:
            try:
                os.killpg(os.getpgid(process.pid), 9)
            except:
                pass
            try:
                process.terminate()
                process.wait(timeout=1)
            except:
                pass
            client_socket.close()
            self.active_connections -= 1
            print(f"[-] Desconectado {address[0]}:{address[1]} ({self.active_connections} activas)")
    
    def start(self):
        try:
            self.socket.bind((self.host, self.port))
            self.socket.listen(5)
            print(f"[+] Servidor escuchando en {self.host}:{self.port}")
            print(f"[+] Máximo {self.max_connections} conexiones simultáneas")
            
            while True:
                client_socket, address = self.socket.accept()
                
                if self.active_connections >= self.max_connections:
                    client_socket.send(b"Server full. Try again later.\n")
                    client_socket.close()
                    continue
                
                self.active_connections += 1
                client_thread = threading.Thread(
                    target=self.handle_client, 
                    args=(client_socket, address)
                )
                client_thread.daemon = True
                client_thread.start()
                
        except KeyboardInterrupt:
            print("\n[!] Cerrando servidor...")
        except Exception as e:
            print(f"[-] Error del servidor: {e}")
        finally:
            self.socket.close()

if __name__ == "__main__":   
    server = JailServer()
    server.start()
